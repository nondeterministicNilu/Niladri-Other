# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'MyFantasyGame.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox

dic={}

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        global dic
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(761, 594)
        font = QtGui.QFont()
        font.setFamily("Book Antiqua")
        MainWindow.setFont(font)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout_4 = QtWidgets.QGridLayout()
        self.gridLayout_4.setContentsMargins(50, 30, 50, 10)
        self.gridLayout_4.setObjectName("gridLayout_4")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout_4.addWidget(self.label_2, 0, 6, 1, 1)
        self.nBat = QtWidgets.QLineEdit(self.centralwidget)
        self.nBat.setReadOnly(True)
        self.nBat.setObjectName("nBat")
        self.gridLayout_4.addWidget(self.nBat, 0, 1, 1, 1)
        self.nAR = QtWidgets.QLineEdit(self.centralwidget)
        self.nAR.setReadOnly(True)
        self.nAR.setObjectName("nAR")
        self.gridLayout_4.addWidget(self.nAR, 0, 7, 1, 1)
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setObjectName("label")
        self.gridLayout_4.addWidget(self.label, 0, 9, 1, 1)
        self.nBowl = QtWidgets.QLineEdit(self.centralwidget)
        self.nBowl.setReadOnly(True)
        self.nBowl.setObjectName("nBowl")
        self.gridLayout_4.addWidget(self.nBowl, 0, 4, 1, 1)
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setObjectName("label_4")
        self.gridLayout_4.addWidget(self.label_4, 0, 0, 1, 1)
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setObjectName("label_3")
        self.gridLayout_4.addWidget(self.label_3, 0, 3, 1, 1)
        self.nWK = QtWidgets.QLineEdit(self.centralwidget)
        self.nWK.setReadOnly(True)
        self.nWK.setObjectName("nWK")
        self.gridLayout_4.addWidget(self.nWK, 0, 10, 1, 1)
        self.label_11 = QtWidgets.QLabel(self.centralwidget)
        self.label_11.setAlignment(QtCore.Qt.AlignCenter)
        self.label_11.setObjectName("label_11")
        self.gridLayout_4.addWidget(self.label_11, 1, 1, 1, 1)
        self.label_13 = QtWidgets.QLabel(self.centralwidget)
        self.label_13.setAlignment(QtCore.Qt.AlignCenter)
        self.label_13.setObjectName("label_13")
        self.gridLayout_4.addWidget(self.label_13, 1, 7, 1, 1)
        self.label_12 = QtWidgets.QLabel(self.centralwidget)
        self.label_12.setAlignment(QtCore.Qt.AlignCenter)
        self.label_12.setObjectName("label_12")
        self.gridLayout_4.addWidget(self.label_12, 1, 4, 1, 1)
        self.label_14 = QtWidgets.QLabel(self.centralwidget)
        self.label_14.setAlignment(QtCore.Qt.AlignCenter)
        self.label_14.setObjectName("label_14")
        self.gridLayout_4.addWidget(self.label_14, 1, 10, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout_4)
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setContentsMargins(30, -1, 30, -1)
        self.gridLayout.setObjectName("gridLayout")
        self.scrlArea = QtWidgets.QScrollArea(self.centralwidget)
        self.scrlArea.setWidgetResizable(True)
        self.scrlArea.setObjectName("scrlArea")
        self.scrollAreaWidgetContents_4 = QtWidgets.QWidget()
        self.scrollAreaWidgetContents_4.setGeometry(QtCore.QRect(0, 0, 186, 331))
        self.scrollAreaWidgetContents_4.setObjectName("scrollAreaWidgetContents_4")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.scrollAreaWidgetContents_4)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.pb10 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb10.setObjectName("pb10")
        self.gridLayout_2.addWidget(self.pb10, 13, 2, 1, 1)
        self.LE7 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE7.setReadOnly(True)
        self.LE7.setObjectName("LE7")
        self.gridLayout_2.addWidget(self.LE7, 9, 0, 1, 1)
        self.LE4 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE4.setReadOnly(True)
        self.LE4.setObjectName("LE4")
        self.gridLayout_2.addWidget(self.LE4, 5, 0, 1, 1)
        self.d9 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d9.setMinimum(1)
        self.d9.setMaximum(40)
        self.d9.setObjectName("d9")
        self.gridLayout_2.addWidget(self.d9, 12, 1, 1, 1)
        self.LE11 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE11.setReadOnly(True)
        self.LE11.setObjectName("LE11")
        self.gridLayout_2.addWidget(self.LE11, 14, 0, 1, 1)
        self.LE8 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE8.setReadOnly(True)
        self.LE8.setObjectName("LE8")
        self.gridLayout_2.addWidget(self.LE8, 11, 0, 1, 1)
        self.pb1 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb1.setObjectName("pb1")
        self.gridLayout_2.addWidget(self.pb1, 1, 2, 1, 1)
        self.pb3 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb3.setObjectName("pb3")
        self.gridLayout_2.addWidget(self.pb3, 3, 2, 1, 1)
        self.pb4 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb4.setObjectName("pb4")
        self.gridLayout_2.addWidget(self.pb4, 5, 2, 1, 1)
        self.d10 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d10.setMinimum(1)
        self.d10.setMaximum(40)
        self.d10.setObjectName("d10")
        self.gridLayout_2.addWidget(self.d10, 13, 1, 1, 1)
        self.LE5 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE5.setReadOnly(True)
        self.LE5.setObjectName("LE5")
        self.gridLayout_2.addWidget(self.LE5, 6, 0, 1, 1)
        self.d1 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d1.setMinimum(1)
        self.d1.setMaximum(40)
        self.d1.setObjectName("d1")
        self.gridLayout_2.addWidget(self.d1, 1, 1, 1, 1)
        self.pb5 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb5.setObjectName("pb5")
        self.gridLayout_2.addWidget(self.pb5, 6, 2, 1, 1)
        self.d3 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d3.setMinimum(1)
        self.d3.setMaximum(40)
        self.d3.setObjectName("d3")
        self.gridLayout_2.addWidget(self.d3, 3, 1, 1, 1)
        self.pb11 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb11.setObjectName("pb11")
        self.gridLayout_2.addWidget(self.pb11, 14, 2, 1, 1)
        self.LE6 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE6.setReadOnly(True)
        self.LE6.setObjectName("LE6")
        self.gridLayout_2.addWidget(self.LE6, 7, 0, 1, 1)
        self.d2 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d2.setMinimum(1)
        self.d2.setMaximum(40)
        self.d2.setObjectName("d2")
        self.gridLayout_2.addWidget(self.d2, 2, 1, 1, 1)
        self.d11 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d11.setMinimum(1)
        self.d11.setMaximum(40)
        self.d11.setObjectName("d11")
        self.gridLayout_2.addWidget(self.d11, 14, 1, 1, 1)
        self.LE10 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE10.setReadOnly(True)
        self.LE10.setObjectName("LE10")
        self.gridLayout_2.addWidget(self.LE10, 13, 0, 1, 1)
        self.pb7 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb7.setObjectName("pb7")
        self.gridLayout_2.addWidget(self.pb7, 9, 2, 1, 1)
        self.LE1 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE1.setText("")
        self.LE1.setReadOnly(True)
        self.LE1.setObjectName("LE1")
        self.gridLayout_2.addWidget(self.LE1, 1, 0, 1, 1)
        self.d7 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d7.setMinimum(1)
        self.d7.setMaximum(40)
        self.d7.setObjectName("d7")
        self.gridLayout_2.addWidget(self.d7, 9, 1, 1, 1)
        self.d5 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d5.setMinimum(1)
        self.d5.setMaximum(40)
        self.d5.setObjectName("d5")
        self.gridLayout_2.addWidget(self.d5, 6, 1, 1, 1)
        self.LE2 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE2.setReadOnly(True)
        self.LE2.setObjectName("LE2")
        self.gridLayout_2.addWidget(self.LE2, 2, 0, 1, 1)
        self.d6 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d6.setMinimum(1)
        self.d6.setMaximum(40)
        self.d6.setObjectName("d6")
        self.gridLayout_2.addWidget(self.d6, 7, 1, 1, 1)
        self.pb8 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb8.setObjectName("pb8")
        self.gridLayout_2.addWidget(self.pb8, 11, 2, 1, 1)
        self.d4 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d4.setMinimum(1)
        self.d4.setMaximum(40)
        self.d4.setObjectName("d4")
        self.gridLayout_2.addWidget(self.d4, 5, 1, 1, 1)
        self.LE3 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE3.setReadOnly(True)
        self.LE3.setObjectName("LE3")
        self.gridLayout_2.addWidget(self.LE3, 3, 0, 1, 1)
        self.LE9 = QtWidgets.QLineEdit(self.scrollAreaWidgetContents_4)
        self.LE9.setReadOnly(True)
        self.LE9.setObjectName("LE9")
        self.gridLayout_2.addWidget(self.LE9, 12, 0, 1, 1)
        self.d8 = QtWidgets.QSpinBox(self.scrollAreaWidgetContents_4)
        self.d8.setMinimum(1)
        self.d8.setMaximum(40)
        self.d8.setObjectName("d8")
        self.gridLayout_2.addWidget(self.d8, 11, 1, 1, 1)
        self.pb2 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb2.setObjectName("pb2")
        self.gridLayout_2.addWidget(self.pb2, 2, 2, 1, 1)
        self.pb9 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb9.setObjectName("pb9")
        self.gridLayout_2.addWidget(self.pb9, 12, 2, 1, 1)
        self.pb6 = QtWidgets.QPushButton(self.scrollAreaWidgetContents_4)
        self.pb6.setObjectName("pb6")
        self.gridLayout_2.addWidget(self.pb6, 7, 2, 1, 1)
        self.scrlArea.setWidget(self.scrollAreaWidgetContents_4)
        self.gridLayout.addWidget(self.scrlArea, 12, 3, 1, 1)
        spacerItem = QtWidgets.QSpacerItem(15, 20, QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 12, 2, 1, 1)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setContentsMargins(5, 5, 15, 5)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setObjectName("label_6")
        self.horizontalLayout_3.addWidget(self.label_6)
        self.pro = QtWidgets.QProgressBar(self.centralwidget)
        self.pro.setProperty("value", 0)
        self.pro.setObjectName("pro")
        self.horizontalLayout_3.addWidget(self.pro)
        self.gridLayout.addLayout(self.horizontalLayout_3, 1, 1, 1, 1)
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_5.setContentsMargins(20, -1, 30, 5)
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setObjectName("label_5")
        self.horizontalLayout_5.addWidget(self.label_5)
        self.point = QtWidgets.QLineEdit(self.centralwidget)
        self.point.setReadOnly(True)
        self.point.setObjectName("point")
        self.horizontalLayout_5.addWidget(self.point)
        self.gridLayout.addLayout(self.horizontalLayout_5, 1, 3, 1, 1)
        spacerItem1 = QtWidgets.QSpacerItem(30, 20, QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem1, 1, 2, 1, 1)
        self.scrollArea = QtWidgets.QScrollArea(self.centralwidget)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents_2 = QtWidgets.QWidget()
        self.scrollAreaWidgetContents_2.setGeometry(QtCore.QRect(0, 0, 464, 262))
        self.scrollAreaWidgetContents_2.setObjectName("scrollAreaWidgetContents_2")
        self.gridLayout_3 = QtWidgets.QGridLayout(self.scrollAreaWidgetContents_2)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.te1 = QtWidgets.QTextEdit(self.scrollAreaWidgetContents_2)
        self.te1.setReadOnly(True)
        self.te1.setObjectName("te1")
        self.gridLayout_3.addWidget(self.te1, 1, 0, 1, 1)
        self.te2 = QtWidgets.QTextEdit(self.scrollAreaWidgetContents_2)
        self.te2.setReadOnly(True)
        self.te2.setObjectName("te2")
        self.gridLayout_3.addWidget(self.te2, 1, 1, 1, 1)
        self.scrollArea.setWidget(self.scrollAreaWidgetContents_2)
        self.gridLayout.addWidget(self.scrollArea, 12, 1, 1, 1)
        self.horizontalLayout_7 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setObjectName("label_7")
        self.horizontalLayout_7.addWidget(self.label_7)
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setObjectName("lineEdit")
        self.horizontalLayout_7.addWidget(self.lineEdit)
        self.line = QtWidgets.QFrame(self.centralwidget)
        self.line.setFrameShape(QtWidgets.QFrame.VLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.horizontalLayout_7.addWidget(self.line)
        self.gridLayout.addLayout(self.horizontalLayout_7, 3, 3, 1, 1)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.gridLayout.addLayout(self.horizontalLayout_2, 5, 3, 1, 1)
        self.horizontalLayout_6 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.rb1 = QtWidgets.QRadioButton(self.centralwidget)
        self.rb1.setObjectName("rb1")
        self.horizontalLayout_6.addWidget(self.rb1)
        self.rb2 = QtWidgets.QRadioButton(self.centralwidget)
        self.rb2.setObjectName("rb2")
        self.horizontalLayout_6.addWidget(self.rb2)
        self.rb3 = QtWidgets.QRadioButton(self.centralwidget)
        self.rb3.setObjectName("rb3")
        self.horizontalLayout_6.addWidget(self.rb3)
        self.rb4 = QtWidgets.QRadioButton(self.centralwidget)
        self.rb4.setObjectName("rb4")
        self.horizontalLayout_6.addWidget(self.rb4)
        self.rb5 = QtWidgets.QRadioButton(self.centralwidget)
        self.rb5.setObjectName("rb5")
        self.horizontalLayout_6.addWidget(self.rb5)
        self.gridLayout.addLayout(self.horizontalLayout_6, 3, 1, 1, 1)
        self.horizontalLayout_8 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_8.setObjectName("horizontalLayout_8")
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setObjectName("label_9")
        self.horizontalLayout_8.addWidget(self.label_9)
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setObjectName("label_8")
        self.horizontalLayout_8.addWidget(self.label_8)
        self.gridLayout.addLayout(self.horizontalLayout_8, 7, 1, 1, 1)
        self.horizontalLayout_9 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_9.setObjectName("horizontalLayout_9")
        self.cb = QtWidgets.QComboBox(self.centralwidget)
        self.cb.setObjectName("cb")
        self.horizontalLayout_9.addWidget(self.cb)
        self.psb = QtWidgets.QPushButton(self.centralwidget)
        self.psb.setObjectName("psb")
        self.horizontalLayout_9.addWidget(self.psb)
        self.gridLayout.addLayout(self.horizontalLayout_9, 7, 3, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setContentsMargins(-1, -1, 30, -1)
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem2)
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.label_10.setObjectName("label_10")
        self.horizontalLayout_4.addWidget(self.label_10)
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout_4.addWidget(self.pushButton)
        self.spinBox = QtWidgets.QSpinBox(self.centralwidget)
        self.spinBox.setMinimum(1)
        self.spinBox.setMaximum(11)
        self.spinBox.setObjectName("spinBox")
        self.horizontalLayout_4.addWidget(self.spinBox)
        self.verticalLayout.addLayout(self.horizontalLayout_4)
        self.gridLayout_5 = QtWidgets.QGridLayout()
        self.gridLayout_5.setContentsMargins(-1, -1, 30, -1)
        self.gridLayout_5.setObjectName("gridLayout_5")
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout_5.addItem(spacerItem3, 1, 0, 1, 1)
        self.label_15 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(7)
        self.label_15.setFont(font)
        self.label_15.setAlignment(QtCore.Qt.AlignCenter)
        self.label_15.setObjectName("label_15")
        self.gridLayout_5.addWidget(self.label_15, 1, 1, 1, 1)
        self.label_16 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(5)
        self.label_16.setFont(font)
        self.label_16.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.label_16.setObjectName("label_16")
        self.gridLayout_5.addWidget(self.label_16, 0, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout_5)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 761, 21))
        self.menubar.setObjectName("menubar")
        self.menuManage_Teams = QtWidgets.QMenu(self.menubar)
        self.menuManage_Teams.setObjectName("menuManage_Teams")
        self.menuRules = QtWidgets.QMenu(self.menubar)
        self.menuRules.setObjectName("menuRules")
        self.menuTeam_Selection_Rule = QtWidgets.QMenu(self.menuRules)
        self.menuTeam_Selection_Rule.setObjectName("menuTeam_Selection_Rule")
        self.menuPlayer_Number = QtWidgets.QMenu(self.menuTeam_Selection_Rule)
        self.menuPlayer_Number.setObjectName("menuPlayer_Number")
        self.menuFantasy_Match_Rule = QtWidgets.QMenu(self.menuRules)
        self.menuFantasy_Match_Rule.setObjectName("menuFantasy_Match_Rule")
        self.menuPoint_System = QtWidgets.QMenu(self.menuFantasy_Match_Rule)
        self.menuPoint_System.setObjectName("menuPoint_System")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.actionNew_Team = QtWidgets.QAction(MainWindow)
        self.actionNew_Team.setObjectName("actionNew_Team")
        self.actionSave_Team = QtWidgets.QAction(MainWindow)
        self.actionSave_Team.setEnabled(False)
        self.actionSave_Team.setShortcutContext(QtCore.Qt.WindowShortcut)
        self.actionSave_Team.setObjectName("actionSave_Team")
        self.actionEvaluate_Team = QtWidgets.QAction(MainWindow)
        self.actionEvaluate_Team.setObjectName("actionEvaluate_Team")
        self.actionabc = QtWidgets.QAction(MainWindow)
        self.actionabc.setObjectName("actionabc")
        self.actionUser_Guide = QtWidgets.QAction(MainWindow)
        self.actionUser_Guide.setObjectName("actionUser_Guide")
        self.actionGame_Rule = QtWidgets.QAction(MainWindow)
        self.actionGame_Rule.setObjectName("actionGame_Rule")
        self.actionUser_Guide_2 = QtWidgets.QAction(MainWindow)
        self.actionUser_Guide_2.setObjectName("actionUser_Guide_2")
        self.actionBatsman = QtWidgets.QAction(MainWindow)
        self.actionBatsman.setObjectName("actionBatsman")
        self.actionBowler = QtWidgets.QAction(MainWindow)
        self.actionBowler.setObjectName("actionBowler")
        self.actionAll_Rounder = QtWidgets.QAction(MainWindow)
        self.actionAll_Rounder.setObjectName("actionAll_Rounder")
        self.actionWicket_Keeper = QtWidgets.QAction(MainWindow)
        self.actionWicket_Keeper.setObjectName("actionWicket_Keeper")
        self.actionTotal = QtWidgets.QAction(MainWindow)
        self.actionTotal.setObjectName("actionTotal")
        self.actionPoint_System_2 = QtWidgets.QAction(MainWindow)
        self.actionPoint_System_2.setObjectName("actionPoint_System_2")
        self.actionBatting = QtWidgets.QAction(MainWindow)
        self.actionBatting.setObjectName("actionBatting")
        self.actionBowling = QtWidgets.QAction(MainWindow)
        self.actionBowling.setObjectName("actionBowling")
        self.actionFielding = QtWidgets.QAction(MainWindow)
        self.actionFielding.setObjectName("actionFielding")
        self.actionPoint_System_3 = QtWidgets.QAction(MainWindow)
        self.actionPoint_System_3.setObjectName("actionPoint_System_3")
        self.menuManage_Teams.addAction(self.actionNew_Team)
        self.menuManage_Teams.addAction(self.actionSave_Team)
        self.menuManage_Teams.addAction(self.actionEvaluate_Team)
        self.menuPlayer_Number.addSeparator()
        self.menuPlayer_Number.addAction(self.actionBatsman)
        self.menuPlayer_Number.addAction(self.actionBowler)
        self.menuPlayer_Number.addAction(self.actionAll_Rounder)
        self.menuPlayer_Number.addAction(self.actionWicket_Keeper)
        self.menuPlayer_Number.addAction(self.actionTotal)
        self.menuTeam_Selection_Rule.addSeparator()
        self.menuTeam_Selection_Rule.addAction(self.menuPlayer_Number.menuAction())
        self.menuTeam_Selection_Rule.addAction(self.actionPoint_System_3)
        self.menuPoint_System.addAction(self.actionBatting)
        self.menuPoint_System.addAction(self.actionBowling)
        self.menuPoint_System.addAction(self.actionFielding)
        self.menuFantasy_Match_Rule.addAction(self.menuPoint_System.menuAction())
        self.menuFantasy_Match_Rule.addAction(self.actionGame_Rule)
        self.menuFantasy_Match_Rule.addAction(self.actionUser_Guide_2)
        self.menuRules.addAction(self.menuTeam_Selection_Rule.menuAction())
        self.menuRules.addAction(self.menuFantasy_Match_Rule.menuAction())
        self.menubar.addAction(self.menuManage_Teams.menuAction())
        self.menubar.addAction(self.menuRules.menuAction())
        import sqlite3
        db=sqlite3.connect('MyFantasyDatabase.db')
        curdb=db.cursor()
        curdb.execute("SELECT TeamName FROM teams")
        result=curdb.fetchall()
        i=0
        for x in result:
            self.cb.addItem("")
            i+=1
        db.close()
        dic={}


        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.rb1.toggled.connect(self.radioTask)
        self.rb2.toggled.connect(self.radioTask)
        self.rb3.toggled.connect(self.radioTask)
        self.rb4.toggled.connect(self.radioTask)
        self.rb5.toggled.connect(self.radioTask)
        self.pb1.clicked.connect(lambda:self.teamSelect(self.pb1,dic))
        self.pb2.clicked.connect(lambda:self.teamSelect(self.pb2,dic))
        self.pb3.clicked.connect(lambda:self.teamSelect(self.pb3,dic))
        self.pb4.clicked.connect(lambda:self.teamSelect(self.pb4,dic))
        self.pb5.clicked.connect(lambda:self.teamSelect(self.pb5,dic))
        self.pb6.clicked.connect(lambda:self.teamSelect(self.pb6,dic))
        self.pb7.clicked.connect(lambda:self.teamSelect(self.pb7,dic))
        self.pb8.clicked.connect(lambda:self.teamSelect(self.pb8,dic))
        self.pb9.clicked.connect(lambda:self.teamSelect(self.pb9,dic))
        self.pb10.clicked.connect(lambda:self.teamSelect(self.pb10,dic))
        self.pb11.clicked.connect(lambda:self.teamSelect(self.pb11,dic))
        self.menuManage_Teams.triggered[QtWidgets.QAction].connect(self.menufunction)
        self.menuTeam_Selection_Rule.triggered[QtWidgets.QAction].connect(self.teamSelectionRule)
        self.menuFantasy_Match_Rule.triggered[QtWidgets.QAction].connect(self.fantasyMatchRule)
        self.pushButton.clicked.connect(self.yourCaptain)
        self.psb.clicked.connect(self.openTeam)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "All-Rounder:"))
        self.nBat.setText(_translate("MainWindow", "0"))
        self.nAR.setText(_translate("MainWindow", "0"))
        self.label.setText(_translate("MainWindow", "Wicket Keeper:"))
        self.nBowl.setText(_translate("MainWindow", "0"))
        self.label_4.setText(_translate("MainWindow", "Batsman:"))
        self.label_3.setText(_translate("MainWindow", "Bowler:"))
        self.nWK.setText(_translate("MainWindow", "0"))
        self.label_11.setText(_translate("MainWindow", "Min: 4         Max: 6"))
        self.label_13.setText(_translate("MainWindow", "Min: 1         Max: 3"))
        self.label_12.setText(_translate("MainWindow", "Min: 3         Max: 5"))
        self.label_14.setText(_translate("MainWindow", "Min: 1         Max: 1"))
        self.pb10.setText(_translate("MainWindow", "Player 10"))
        self.pb1.setText(_translate("MainWindow", "Player 1"))
        self.pb3.setText(_translate("MainWindow", "Player 3"))
        self.pb4.setText(_translate("MainWindow", "Player 4"))
        self.pb5.setText(_translate("MainWindow", "Player 5"))
        self.pb11.setText(_translate("MainWindow", "Player 11"))
        self.pb7.setText(_translate("MainWindow", "Player 7"))
        self.pb8.setText(_translate("MainWindow", "Player 8"))
        self.pb2.setText(_translate("MainWindow", "Player 2"))
        self.pb9.setText(_translate("MainWindow", "Player 9"))
        self.pb6.setText(_translate("MainWindow", "Player 6"))
        self.label_6.setText(_translate("MainWindow", "Progress Bar:"))
        self.label_5.setText(_translate("MainWindow", "Points Available:"))
        self.point.setText(_translate("MainWindow", "100"))
        self.label_7.setText(_translate("MainWindow", "Team Name:"))
        self.rb1.setText(_translate("MainWindow", "Bat"))
        self.rb2.setText(_translate("MainWindow", "Bowl"))
        self.rb3.setText(_translate("MainWindow", "AR"))
        self.rb4.setText(_translate("MainWindow", "WK"))
        self.rb5.setText(_translate("MainWindow", "All Players"))
        self.label_9.setText(_translate("MainWindow", "Players\' Rating Point with Search number:"))
        self.label_8.setText(_translate("MainWindow", "Players\' Name with Search number:"))
        self.psb.setText(_translate("MainWindow", "Open Team"))
        self.label_10.setText(_translate("MainWindow", "Select Your Captain"))
        self.pushButton.setText(_translate("MainWindow", "Player:"))
        self.label_15.setText(_translate("MainWindow", "Choose Your Captain to Unlock the Save Team Button"))
        self.label_16.setText(_translate("MainWindow", "If you choose 6 then \'Player 6\' from the above list will be your captain"))
        self.menuManage_Teams.setTitle(_translate("MainWindow", "Manage Teams"))
        self.menuRules.setTitle(_translate("MainWindow", "Rules"))
        self.menuTeam_Selection_Rule.setTitle(_translate("MainWindow", "Team Selection Rule"))
        self.menuPlayer_Number.setTitle(_translate("MainWindow", "Player Number"))
        self.menuFantasy_Match_Rule.setTitle(_translate("MainWindow", "Fantasy Match Rule"))
        self.menuPoint_System.setTitle(_translate("MainWindow", "Point System"))
        self.actionNew_Team.setText(_translate("MainWindow", "New Team"))
        self.actionSave_Team.setText(_translate("MainWindow", "Save Team"))
        self.actionEvaluate_Team.setText(_translate("MainWindow", "Evaluate Team"))
        self.actionabc.setText(_translate("MainWindow", "abc"))
        self.actionUser_Guide.setText(_translate("MainWindow", "User Guide"))
        self.actionGame_Rule.setText(_translate("MainWindow", "Game Rule"))
        self.actionUser_Guide_2.setText(_translate("MainWindow", "User Guide"))
        self.actionBatsman.setText(_translate("MainWindow", "Batsman"))
        self.actionBowler.setText(_translate("MainWindow", "Bowler"))
        self.actionAll_Rounder.setText(_translate("MainWindow", "All Rounder"))
        self.actionWicket_Keeper.setText(_translate("MainWindow", "Wicket Keeper"))
        self.actionTotal.setText(_translate("MainWindow", "Total"))
        self.actionPoint_System_2.setText(_translate("MainWindow", "Point System"))
        self.actionBatting.setText(_translate("MainWindow", "Batting"))
        self.actionBowling.setText(_translate("MainWindow", "Bowling"))
        self.actionFielding.setText(_translate("MainWindow", "Fielding"))
        self.actionPoint_System_3.setText(_translate("MainWindow", "Point System"))
        import sqlite3
        db=sqlite3.connect('MyFantasyDatabase.db')
        curdb=db.cursor()
        curdb.execute("SELECT TeamName FROM teams")
        result=curdb.fetchall()
        result.sort()
        i=0
        for x in result:
            self.cb.setItemText(i, _translate("Form", x[0]))
            i+=1
        db.close()

    def radioTask(self):
        import sqlite3
        db=sqlite3.connect('MyFantasyDatabase.db')
        curdb=db.cursor()
        f=open("abc.txt","w")
        f.write("")
        f.close()
        g=open("abc1.txt","w")
        g.write("")
        g.close()
        if self.rb5.isChecked()==True:
            curdb.execute("SELECT * FROM PlayersList"";")
            result=curdb.fetchall()
            f=open("abc.txt","a")
            g=open("abc1.txt","a")
            for rs in result:
                t=str(rs[0])+': '+rs[1]+'\n'
                s=str(rs[0])+': '+str(rs[3])+'\n'
                f.write(t)
                g.write(s)
            f.close()
            g.close()
            f=open("abc.txt","r")
            g=open("abc1.txt","r")
            t=f.read()
            s=g.read()
            self.te1.setText(t)
            self.te2.setText(s)
            f.close()
            g.close()
        else:
            if self.rb1.isChecked()==True:
                txt='Bat'
            if self.rb2.isChecked()==True:
                txt='Bowl'
            if self.rb3.isChecked()==True:
                txt='AR'
            if self.rb4.isChecked()==True:
                txt='WK'
            sql="SELECT * FROM PlayersList WHERE Role='"+txt+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            f=open("abc.txt","a")
            g=open("abc1.txt","a")
            for rs in result:
                t=str(rs[0])+': '+rs[1]+'\n'
                s=str(rs[0])+': '+str(rs[3])+'\n'
                f.write(t)
                g.write(s)
            f.close()
            g.close()
            f=open("abc.txt","r")
            g=open("abc1.txt","r")
            t=f.read()
            s=g.read()
            self.te1.setText(t)
            self.te2.setText(s)
            f.close()
            g.close()
        db.close()

    def teamSelect(self,pb,dic):
        k=pb.text()
        import re
        n=int((re.findall(r'\d+',k))[0])
        import sqlite3
        db=sqlite3.connect('MyFantasyDatabase.db')
        curdb=db.cursor()
        s=0
        if len(dic)>0:
            for i in dic:
                if i is not n:
                    s+=dic[i][0][3]
        if n is 1:
            x=self.d1.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE1.setText(result[0][1])
        elif n is 2:
            x=self.d2.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE2.setText(result[0][1])
        elif n is 3:
            x=self.d3.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE3.setText(result[0][1])
        elif n is 4:
            x=self.d4.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE4.setText(result[0][1])
        elif n is 5:
            x=self.d5.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE5.setText(result[0][1])
        elif n is 6:
            x=self.d6.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE6.setText(result[0][1])
        elif n is 7:
            x=self.d7.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE7.setText(result[0][1])
        elif n is 8:
            x=self.d8.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE8.setText(result[0][1])
        elif n is 9:
            x=self.d9.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE9.setText(result[0][1])
        elif n is 10:
            x=self.d10.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE10.setText(result[0][1])
        else:
            x=self.d11.text()
            sql="SELECT * FROM PlayersList WHERE SLno='"+x+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            s+=result[0][3]
            point=100-s
            if result not in dic.values() and point>=0:
                self.point.setText(str(point))
                dic[n]=result
                self.LE11.setText(result[0][1])
        val=len(dic)/11*100
        n1=n2=n3=n4=0
        for i in dic:
            if dic[i][0][2]=='Bat':
                n1+=1
            elif dic[i][0][2]=='Bowl':
                n2+=1
            elif dic[i][0][2]=='AR':
                n3+=1
            else:
                n4+=1
        self.nBat.setText(str(n1))
        self.nBowl.setText(str(n2))
        self.nAR.setText(str(n3))
        self.nWK.setText(str(n4))
        self.pro.setProperty("value", val)
        db.close()

    def menufunction(self, action):
        global dic
        txt= (action.text())
        if txt =='New Team':
            dic={}
            self.LE1.setText('')
            self.LE2.setText('')
            self.LE3.setText('')
            self.LE4.setText('')
            self.LE5.setText('')
            self.LE6.setText('')
            self.LE7.setText('')
            self.LE8.setText('')
            self.LE9.setText('')
            self.LE10.setText('')
            self.LE11.setText('')
            self.lineEdit.setText('')
            self.point.setText("100")
            self.nBat.setText("0")
            self.nBowl.setText("0")
            self.nAR.setText("0")
            self.nWK.setText("0")
            self.pro.setProperty("value", 0)
        elif txt =='Save Team':
            import sqlite3
            db=sqlite3.connect('MyFantasyDatabase.db')
            curdb=db.cursor()
            txt=self.lineEdit.text()
            sql="SELECT * FROM teams WHERE TeamName='"+txt+"';"
            curdb.execute(sql)
            result=curdb.fetchall()
            if len(result)>0:
                msg=QMessageBox()
                msg.setWindowTitle("Note")
                msg.setText("Team Name Exists. Do you want to replace it?")
                msg.setIcon(QMessageBox.Question)
                msg.setStandardButtons(QMessageBox.Yes|QMessageBox.No)
                msg.buttonClicked.connect(self.reSave)
                x=msg.exec_()    
            else:
                curdb.execute("INSERT INTO teams (TeamName) VALUES ('"+txt+"')")
                sql="CREATE TABLE "+txt+" (slNo INTEGER PRIMARY KEY, Name TEXT NOT NULL, Role TEXT NOT NULL, IsCaptain BOOLEAN);"
                curdb.execute(sql)
                for i in dic:
                    if i<12:
                        if int(dic[12]) is i:
                            b=1
                        else:
                            b=0
                        m=dic[i][0][1]
                        n=dic[i][0][2]
                        sql="INSERT INTO "+txt+" (slNo, Name, Role, IsCaptain) VALUES ("+str(i)+",'"+m+"','"+n+"',"+str(b)+")" 
                        curdb.execute(sql)
                db.commit()
                db.close()
                msg=QMessageBox()
                msg.setWindowTitle("Note")
                msg.setText("Successfully Saved.")
                msg.setIcon(QMessageBox.Information)
                x=msg.exec_()
        else:
            import os
            os.system('python combined.py')

    def reSave(self, x):
        global dic
        h=x.text()
        h=str(h[1:])
        if h=='No':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("Rename and save again.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        else:
            txt=self.lineEdit.text()
            import sqlite3
            db=sqlite3.connect('MyFantasyDatabase.db')
            curdb=db.cursor()
            curdb.execute("DROP TABLE '"+txt+"'")
            sql="CREATE TABLE "+txt+" (slNo INTEGER PRIMARY KEY, Name TEXT NOT NULL, Role TEXT NOT NULL, IsCaptain BOOLEAN);"
            curdb.execute(sql)
            for i in dic:
                if i<12:
                    if int(dic[12]) is i:
                        b=1
                    else:
                        b=0
                    m=dic[i][0][1]
                    n=dic[i][0][2]
                    sql="INSERT INTO "+txt+" (slNo, Name, Role, IsCaptain) VALUES ("+str(i)+",'"+m+"','"+n+"',"+str(b)+")" 
                    curdb.execute(sql)
            db.commit()
            db.close()
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("Successfully Re-Saved.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
            
        
    def context_menu(MainWindow):
        menu = QtWidgets.QMenu()
        menu.addAction("Select Captain")
        menu.addAction("Second option")
        menu.exec_(QtGui.QCursor.pos())

    def yourCaptain(self,pushButton):
        global dic
        nBat=int(self.nBat.text())
        nBowl=int(self.nBowl.text())
        nAR=int(self.nAR.text())
        nWK=int(self.nWK.text())
        nm=self.lineEdit.text()
        if len(nm)>0 and len(dic)>10 and nBat in range(4,7) and nBowl in range(3,6) and nAR in range(1,4) and nWK in range(1,2):
            no=self.spinBox.text()
            dic[12]=no
            self.actionSave_Team.setEnabled(True)
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("Team Added. You may save now.")
            x=msg.exec_()
        else:
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("Error in Team Selection!")
            msg.setIcon(QMessageBox.Critical)
            msg.setDetailedText("● Team member number<11\n● Batsman/Bowler/AllRounder/WicketKeeper number not in range.\n● Team Name hasn't been set yet.\n\nCheck out the Rules.")
            x=msg.exec_()

    def openTeam(self,psb):
        global dic
        txt=self.cb.currentText()
        import sqlite3
        db=sqlite3.connect('MyFantasyDatabase.db')
        curdb=db.cursor()
        curdb.execute("SELECT Name FROM "+txt)
        result=curdb.fetchall()
        self.LE1.setText(result[0][0])
        self.LE2.setText(result[1][0])
        self.LE3.setText(result[2][0])
        self.LE4.setText(result[3][0])
        self.LE5.setText(result[4][0])
        self.LE6.setText(result[5][0])
        self.LE7.setText(result[6][0])
        self.LE8.setText(result[7][0])
        self.LE9.setText(result[8][0])
        self.LE10.setText(result[9][0])
        self.LE11.setText(result[10][0])
        self.lineEdit.setText(txt)
        self.pro.setProperty("value", 0)
        i=0
        s=0
        for x in result:
            i+=1
            curdb.execute("SELECT * FROM PlayersList WHERE Name='"+x[0]+"'")
            result1=curdb.fetchall()
            s+=result1[0][3]
            dic[i]=result1
        n=100-s
        self.point.setText(str(n))
        curdb.execute("SELECT Name FROM "+txt+" WHERE Role='Bat'")
        n1=len(curdb.fetchall())
        self.nBat.setText(str(n1))
        curdb.execute("SELECT Name FROM "+txt+" WHERE Role='Bowl'")
        n2=len(curdb.fetchall())
        self.nBowl.setText(str(n2))
        curdb.execute("SELECT Name FROM "+txt+" WHERE Role='AR'")
        n3=len(curdb.fetchall())
        self.nAR.setText(str(n3))
        curdb.execute("SELECT Name FROM "+txt+" WHERE Role='WK'")
        n4=len(curdb.fetchall())
        self.nWK.setText(str(n4))
        db.close()
        msg=QMessageBox()
        msg.setWindowTitle("Note")
        msg.setText("Select your captain to the ReSave Team")
        msg.setIcon(QMessageBox.Information)
        x=msg.exec_()

    def teamSelectionRule(self, action):
        txt= (action.text())
        if txt=='Batsman':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("There must be at least 4 and at most 6 batsmen in the team.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        elif txt=='Bowler':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("There must be at least 3 and at most 5 bowlers in the team.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        elif txt=='All Rounder':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("There must be at least 1 and at most 3 all-rounder in the team.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        elif txt=='Wicket Keeper':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("There must only one keeper in the team.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        elif txt=='Total':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("Team must be 11-a-side.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        else:
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("Total point should not cross 100.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()

    def fantasyMatchRule(self, action):
        txt=action.text()
        if txt=='Batting':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("● 1 point for 2 runs scored\n● 5 points for half century\n● Additional 10 points for century\n● 2 points for strike rate (runs/balls faced) of 80-100\n● Additional 4 points for strike rate>100\n● 1 point for hitting a boundary (four) and 2 points for over boundary (six)")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        elif txt=='Bowling':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("● 10 points for each wicket\n● Additional 5 points for three wickets per innings\n● Additional 10 points for 5 wickets or more in innings\n● 4 points for economy rate (runs given per over) between 3.5 and 4.5\n● 7 points for economy rate between 2 and 3.5\n● 10 points for economy rate less than 2")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        elif txt=='Fielding':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("10 points each for catch/stumping/run out.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        elif txt=='Game Rule':
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("~●~ CAPTAIN's POINT WILL BE DOUBLE OF HIS ACTUAL POINT ~●~")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        else:
            msg=QMessageBox()
            msg.setWindowTitle("Note")
            msg.setText("After making the team with all the restrictions select captain to save team.\nSelect Match to see your point, rank in the Fantasy Match.\nPress Evaluate Team to go to the Fantasy Page.")
            msg.setIcon(QMessageBox.Information)
            x=msg.exec_()
        

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
