import evaluationTeam
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    wid = evaluationTeam.Ui_Form()
    wid.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())
